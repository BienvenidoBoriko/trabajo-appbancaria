<div class="conatiner div-titulo ">
    <h1 class="text-center titulo"> Bienvenido a mi Banco</h1>
</div>