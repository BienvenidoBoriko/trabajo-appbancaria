<?php
    $titulo='apertura de cuentas';
    $script='views/js/aper_cuentas.js';
    $plantilla = 'views/plantillas/aper_cuentas.php';
     include('views/layouts/layout1.php'); 
?>