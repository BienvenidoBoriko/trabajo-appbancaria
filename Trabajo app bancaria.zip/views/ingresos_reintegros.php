<?php
    $titulo='Ingresos y reintegros';
    $script='views/js/ingresos_reintegros.js';
    $plantilla = 'views/plantillas/ingresos_reintegros.php';
     include('views/layouts/layout1.php'); 
?>