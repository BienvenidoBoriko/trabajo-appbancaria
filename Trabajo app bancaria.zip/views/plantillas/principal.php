<div class="conatiner div-titulo ">
    <h1 class="text-center titulo"> Bienvenido A mi Banco</h1>
</div>