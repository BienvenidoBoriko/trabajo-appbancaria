 $(document).ready(function() {
     $("body").hide();
     $("body").fadeIn(1000);
     $("img").fadeIn(2000);
 });