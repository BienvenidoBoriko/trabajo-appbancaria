<?php
    $titulo='lista de movimientos';
    $script='views/js/l_movimientos.js';
    $plantilla = 'views/plantillas/l_movimientos.php';
     include('views/layouts/layout1.php'); 
?>