<?php
    $titulo='apertura de cuentas';
    $script='views/js/principal.js';
    $plantilla = 'views/plantillas/principal.php';
     include('views/layouts/layout1.php'); 
?>