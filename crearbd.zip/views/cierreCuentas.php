<?php
    $titulo='lista de movimientos';
    $script='views/js/cierreCuentas.js';
    $plantilla = 'views/plantillas/cierreCuentas.php';
     include('views/layouts/layout1.php'); 
?>