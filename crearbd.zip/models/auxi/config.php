<?php 

    define('USUARIO','bienvenido');
    define('CONTRASEÑA','12345');
    define('HOST','localhost');
    define('DB','banco');
?>