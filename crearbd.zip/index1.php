<?php
    require_once('lib/funcionesBasicas.php');
    include('controllers/principal.php');
?>